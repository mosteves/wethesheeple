function statusChangeCallback(response) {
    console.log('statusChangeCallback');
    console.log(response);
    // The response object is returned with a status field that lets the
    // app know the current login status of the person.
    // Full docs on the response object can be found in the documentation
    // for FB.getLoginStatus().
    if (response.status === 'connected') {
       getPhotos();
      }
      else {
        var button = document.createElement("button");
        button.onclick = function(){fblogin();};
        button.innerHTML = "Login";
        document.getElementById("status").appendChild(button);
    }
  }

window.fbAsyncInit = function() {
    FB.init({
      appId      : '1693580894189992',
      xfbml      : true,
      version    : 'v2.5'
    });

    //login
        FB.getLoginStatus(function(response) {
      statusChangeCallback(response);
});
  };

  (function(d, s, id){
 var js, fjs = d.getElementsByTagName(s)[0];
 if (d.getElementById(id)) {return;}
 js = d.createElement(s); js.id = id;
 js.src = "//connect.facebook.net/en_US/sdk.js";
 fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

function getPhotos () {
  FB.api('1350180911674216?fields=photos{images,name}', function(response) {
    console.log(response);
    var photoArray = response.photos.data;
    var row = document.createElement("div");
    $(row).addClass("row");
    var col = document.createElement("div");
    $(col).addClass("col-md-12");
    for (var i = photoArray.length - 1; i >= 0; i--) {
      var img = document.createElement("img");
      var pArr = photoArray[i].images;
      img.src= pArr[1].source;

      var caption = document.createElement("p");
      caption.innerHTML = photoArray[i].name;
      col.appendChild(img);
      col.appendChild(caption);
    }
    $(row).append(col);
    document.getElementById("dash").appendChild(row);

  });

}

$("#submitButton").click(function(){
  var photourl = document.getElementById("photoURL").value;
  var messageText = document.getElementById("messageBox").value;
  console.log(photourl);
  if (photourl.length > 0) {

  } else {
    photourl = "http://41.media.tumblr.com/601b66c8ba834f4a1becac243fb8eeb0/tumblr_o2sx730cRw1ufxsuho1_500.jpg";
  }
  FB.api(
    '1350180911674216/photos',
    "POST",
    {
        'url': photourl,
        'message': messageText
    },
    function (response) {
      console.log(response);
    }
  );
});

